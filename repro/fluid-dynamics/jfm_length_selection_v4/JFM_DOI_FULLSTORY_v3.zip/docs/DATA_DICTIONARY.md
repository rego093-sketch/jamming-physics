see prior message; will be augmented in v2
