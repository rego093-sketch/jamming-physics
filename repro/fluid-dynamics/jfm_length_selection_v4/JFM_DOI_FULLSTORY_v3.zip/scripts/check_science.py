
import json, numpy as np, pandas as pd
from pathlib import Path

def uq_secant(xm, ym):
    slopes=[]
    for i in range(len(xm)):
        for j in range(i+1,len(xm)):
            dx = xm[j]-xm[i]
            if dx!=0: slopes.append((ym[j]-ym[i])/dx)
    return float(np.quantile(np.array(slopes),0.75))

def bin_medians(x, y, nbins=12):
    q = pd.qcut(x, nbins, duplicates='drop')
    g = pd.DataFrame({"x":x,"y":y}).groupby(q, observed=True)
    xm = g.median()["x"].to_numpy(); ym = g.median()["y"].to_numpy()
    return xm, ym

def main(root="."):
    root = Path(root)
    pts = pd.read_csv(root/"source_data/Figure_02_L_vs_S_points.csv")
    xm, ym = bin_medians(pts["logS"], pts["logL"], nbins=12)
    beta_main = uq_secant(xm, ym)
    null = pd.read_csv(root/"tables/timeshift_null.csv")
    beta_null_med = float(null["beta_hat"].median())
    k6 = pd.read_csv(root/"source_data/Synthetic_k6.csv")
    xm2, ym2 = bin_medians(k6["logS"], k6["logL"], nbins=12)
    beta_k6 = uq_secant(xm2, ym2)
    cv = pd.read_csv(root/"data/injection_cv_by_run.csv")
    cv_mean = float(cv["CV_A2"].mean())
    out = {"beta_main": beta_main, "beta_null_med": beta_null_med, "beta_k6": beta_k6, "CV_A2_mean": cv_mean}
    print(json.dumps(out, indent=2))

if __name__=="__main__":
    main()
