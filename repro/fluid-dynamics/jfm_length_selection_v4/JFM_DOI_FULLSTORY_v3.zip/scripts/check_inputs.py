
import os, json, hashlib
from pathlib import Path

REQUIRED = [
  "data/L_S_table.csv",
  "data/meta/RUN_METADATA.csv",
  "source_data/Figure_02_L_vs_S_points.csv",
  "source_data/Figure_02_L_vs_S_bins.csv",
  "source_data/Figure_02_slope_ci.csv",
  "source_data/Placebo_Sprime.csv",
  "source_data/Synthetic_k6.csv",
  "tables/gate_sensitivity.csv",
  "tables/wp_sweep.csv",
  "tables/endogeneity_eiv_ridge.csv",
  "tables/block_bootstrap_ci.csv",
  "tables/timeshift_null.csv",
  "tables/mu_sweep.csv",
  "tables/GATE_LOG_INDEX.csv",
  "data/phase_map/beta_hat.csv",
  "data/linear_response/eps_sigma_by_run.csv",
  "data/budget/budget_run_000.csv"
]

def sha256sum(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for chunk in iter(lambda: f.read(8192), b''):
            h.update(chunk)
    return h.hexdigest()

def main(root="."):
    root = Path(root)
    missing=[]; hashes={}
    for rel in REQUIRED:
        p = root/rel
        if not p.exists():
            missing.append(rel)
        else:
            hashes[rel] = sha256sum(p)
    print(json.dumps({"missing":missing, "hash":hashes}, indent=2))

if __name__=="__main__":
    main()
