FULL STORY v1 built; v2 adds expanded analyses
